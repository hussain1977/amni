<div class="dexp-dropdown">
<?php
  print $items['menu'];
?>
</div>