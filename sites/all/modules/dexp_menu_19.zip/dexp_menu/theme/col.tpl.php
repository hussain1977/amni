<!--begin-->
<div class="<?php print $classes;?>">
    <?php if(isset($title) && $title):?>
    <h3 class="dexp-mega-menu-title"><?php print $title;?></h3>
    <?php endif;?>
    <?php print $content;?>
</div>
<!--end-->