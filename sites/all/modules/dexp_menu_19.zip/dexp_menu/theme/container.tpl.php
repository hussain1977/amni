<!--begin-->
<div<?php print $attributes;?>>
    <?php print_r($content);?>
</div>
<!--end-->