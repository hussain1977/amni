<a data-target="#<?php print $html_id;?>" href="#" class="hidden-lg hidden-md btn btn-inverse dexp-menu-toggler">
	<i class="fa fa-bars"></i>
</a>
<div id="<?php print $html_id;?>" class="<?php print $classes;?>">
<?php
  print $output;
?>
</div>