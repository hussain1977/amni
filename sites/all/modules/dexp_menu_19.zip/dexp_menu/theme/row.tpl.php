<!--begin-->
<div class="<?php print $classes;?>">
    <?php print_r($content);?>
</div>
<!--end-->